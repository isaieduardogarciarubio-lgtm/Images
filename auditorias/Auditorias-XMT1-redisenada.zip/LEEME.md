# Auditorías XMT1 — rediseño visual

`Auditorias-XMT1-redisenada.html` es el archivo final, con estilos y presentación incorporados. Se basa en `Auditorias-XMT1_6.html` y en el diseño del ZIP `rediseno-app-auditorias.zip`.

## Cambios visuales

- Paleta Material 3 oscura, amarillo Meli y superficies cálidas.
- Tarjetas de auditoría agrupadas en sesiones de escaneo y reportes.
- Navegación inferior entre auditorías e historial. Se conserva la ventana de historial original: 5, 15, 30 o 60 minutos.
- Selector handheld/cámara únicamente dentro de las auditorías, junto al escáner. Se conserva el mecanismo original de preferencias.
- Formularios con campos delineados, progreso visual, botones, pickers, escáner y modales actualizados.
- Iniciales del header de 48 × 48 px, con recarga, pantalla completa, consola y salida dentro de su menú. Los controles de consola y salida conservan sus manejadores originales.
- Símbolo de manos sin el texto «mercado libre», redibujado a partir de `ML_es_RGB-07.svg` e incorporado en el HTML. También se usa como favicon e icono del documento; `icono-app.png` incluye el recurso por separado.
- La opción de pantalla completa alterna entrada y salida mediante la API del navegador. Si el visor la bloquea, informa mediante un aviso de la app.
- Teclado que se expande dentro del campo de escaneo, con la transición de la propuesta y el cambio de «Ingresar con teclado» a «Volver al lector». Se conservan el input original, la validación y el retorno al lector HID.
- Ícono de escaneo centrado con su animación original. Los íconos de interfaz son Material Symbols Outlined de Google; los nuevos SVG usan las fuentes oficiales indicadas en `material-icon-sources.json`.
- Avisos con espacio reservado y diálogos con tamaños, capas y foco controlados para evitar que tapen textos, captura y acciones. Al cerrar consola, carga o confirmación se recupera el foco de captura.
- Adaptación a móvil y escritorio, enfoque visible para teclado y respeto de la preferencia de movimiento reducido.

## Funcionamiento conservado

Los diez bloques de JavaScript originales están intactos, byte por byte. Se agregó un bloque independiente de presentación que reorganiza los nodos visuales y reutiliza los manejadores existentes; no sustituye métodos de captura, almacenamiento, catálogos ni sincronización.

Se conservan las ocho auditorías, sus reglas y campos, IndexedDB, la cola pendiente, los catálogos, las solicitudes a Grid, las fotos, los enlaces externos y el cierre de sesión. El código base mantiene el antiguo ID del logo `01KY8S5Z97W0YTQVTX59DDBC05`. Por petición posterior del usuario, la capa de presentación muestra el nuevo símbolo incorporado en el HTML.

El addendum de la Biblia aportado trata el logout (§16.22). Se mantiene su patrón en la app: confirmación propia, iframe oculto de la pasarela, verificación mediante `/api/v1/me`, reintento ante error y bloqueo de la interfaz tras el cierre comprobado. No se trasladaron los datos simulados ni el logout de demostración de la propuesta React.

## Adaptaciones de la propuesta al flujo real

Se reproduce el diseño del ZIP en el HTML autónomo. La propuesta usa datos de ejemplo, escaneo simulado y controles de demostración; aquí se conservan los datos y mecanismos reales de la app. El campo expandible mantiene los botones de confirmar y cancelar que requiere la captura manual original. Las opciones y ventanas del historial siguen siendo las de la app original. Los íconos Lucide de la propuesta se sustituyen por Material Symbols, según lo solicitado. Los avisos reservan espacio en la pantalla para no superponerse con otros objetos.

El nuevo símbolo se muestra también en la vista previa local, sin descargar un activo de Grid. La pantalla completa en el visor real depende de su política de permisos y del navegador. El favicon pertenece al HTML de la app; un visor que encapsule el documento puede conservar el icono de su propia pestaña.

## Validación

`integridad.json` contiene los hashes SHA-256 de los scripts originales conservados. `verificacion.json` registra las comprobaciones realizadas en Chromium:

- Navegación e historial en anchos de 320, 390 y 1440 px.
- Apertura de las ocho auditorías con el mismo motor, pregunta y paso que la original.
- Captura y sincronización de las ocho auditorías, comparando sus registros con los de la original.
- Deduplicación, campos condicionales de LH, fotos FURY/HV, QR, IndexedDB e historial.
- Cancelación de logout, cierre verificado con 401 y error de red sin falso éxito.

`verificacion-visual.json` registra además el centrado y la animación del escáner, la expansión del teclado, el menú de iniciales, el regreso del foco al lector, los avisos y las capas de consola, confirmación y carga. Incluye la entrada y salida reales de pantalla completa en Chromium, su bloqueo mediante Permissions Policy y la presencia del símbolo y las iniciales ampliadas. Estas comprobaciones se realizaron en tamaños de 320 × 568, 390 × 844 y 1440 × 1000 px.

Las APIs de Grid fueron simuladas exclusivamente en las pruebas locales; esas simulaciones no están incluidas en el HTML final. El símbolo incorporado sí se usa en las pruebas y capturas de pantalla. La descarga del viejo activo Grid se simula, pero la presentación lo sustituye por el recurso local. Las fotos se probaron con un dispositivo de cámara virtual de Chromium. No se verificaron una sesión real de Grid, una handheld física, Safari ni la autenticación de producción.

## Uso

Usa el HTML final en el mismo contexto Grid de la app original, conservando sus accesos y configuración. No necesita Next.js, instalar paquetes ni cargar nuevos recursos externos. Las operaciones de datos siguen dependiendo de la sesión y los servicios de Grid existentes.

La entrega se publica en la carpeta `auditorias/` del repositorio GitHub `isaieduardogarciarubio-lgtm/Images`. La actualización del documento Grid `01KZPS3EGSPGS986QMD00F1GX7` requiere conectividad al servicio interno de Fury/Swarm y se realiza con lectura previa de versión y `if_version`. Los informes locales no acreditan una actualización remota de Grid. El archivo original subido permanece intacto.
