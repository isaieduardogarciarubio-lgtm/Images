# Auditorías XMT1 — rediseño visual

`Auditorias-XMT1-redisenada.html` es el archivo final, con estilos y presentación incorporados. Se basa en `Auditorias-XMT1_6.html` y en el diseño del ZIP `rediseno-app-auditorias.zip`.

## Cambios visuales

- Paleta Material 3 oscura, amarillo Meli y superficies cálidas.
- Tarjetas de auditoría agrupadas en sesiones de escaneo y reportes.
- Navegación inferior entre auditorías e historial. Se conserva la ventana de historial original: 5, 15, 30 o 60 minutos.
- Selector handheld/cámara únicamente dentro de las auditorías, junto al escáner. Se conserva el mecanismo original de preferencias.
- Formularios con campos delineados, progreso visual, botones, pickers, escáner y modales actualizados.
- Recarga, consola y salida dentro del menú que se abre al seleccionar las iniciales del header. Los controles de consola y salida conservan sus manejadores originales.
- Teclado que se expande dentro del campo de escaneo, con la transición de la propuesta y el cambio de «Ingresar con teclado» a «Volver al lector». Se conservan el input original, la validación y el retorno al lector HID.
- Ícono de escaneo centrado con su animación original. Los íconos de interfaz son Material Symbols Outlined de Google; los nuevos SVG usan las fuentes oficiales indicadas en `material-icon-sources.json`.
- Avisos con espacio reservado y diálogos con tamaños, capas y foco controlados para evitar que tapen textos, captura y acciones. Al cerrar consola, carga o confirmación se recupera el foco de captura.
- Adaptación a móvil y escritorio, enfoque visible para teclado y respeto de la preferencia de movimiento reducido.

## Funcionamiento conservado

Los diez bloques de JavaScript originales están intactos, byte por byte. Se agregó un bloque independiente de presentación que reorganiza los nodos visuales y reutiliza los manejadores existentes; no sustituye métodos de captura, almacenamiento, catálogos ni sincronización.

Se conservan las ocho auditorías, sus reglas y campos, IndexedDB, la cola pendiente, los catálogos, las solicitudes a Grid, las fotos, los enlaces externos y el cierre de sesión. El logo se sigue descargando con el método original desde el mismo documento Grid: `01KY8S5Z97W0YTQVTX59DDBC05`. No se incorpora un logotipo alternativo.

El addendum de la Biblia aportado trata el logout (§16.22). Se mantiene su patrón en la app: confirmación propia, iframe oculto de la pasarela, verificación mediante `/api/v1/me`, reintento ante error y bloqueo de la interfaz tras el cierre comprobado. No se trasladaron los datos simulados ni el logout de demostración de la propuesta React.

## Adaptaciones de la propuesta al flujo real

Se reproduce el diseño del ZIP en el HTML autónomo. La propuesta usa datos de ejemplo, escaneo simulado y controles de demostración; aquí se conservan los datos y mecanismos reales de la app. El campo expandible mantiene los botones de confirmar y cancelar que requiere la captura manual original. Las opciones y ventanas del historial siguen siendo las de la app original. Los íconos Lucide de la propuesta se sustituyen por Material Symbols, según lo solicitado. Los avisos reservan espacio en la pantalla para no superponerse con otros objetos.

El logotipo original necesita una sesión con acceso al documento de Grid. Abrir el HTML fuera de Grid no proporciona el endpoint de descarga y puede dejar la imagen oculta, igual que en el archivo original. El ID sí está conservado; no se obtuvo ni se reemplazó el activo de producción.

## Validación

`integridad.json` contiene los hashes SHA-256 de los scripts originales conservados. `verificacion.json` registra las comprobaciones realizadas en Chromium:

- Navegación e historial en anchos de 320, 390 y 1440 px.
- Apertura de las ocho auditorías con el mismo motor, pregunta y paso que la original.
- Captura y sincronización de las ocho auditorías, comparando sus registros con los de la original.
- Deduplicación, campos condicionales de LH, fotos FURY/HV, QR, IndexedDB e historial.
- Cancelación de logout, cierre verificado con 401 y error de red sin falso éxito.

`verificacion-visual.json` registra además el centrado y la animación del escáner, la expansión del teclado, el menú de iniciales, el regreso del foco al lector, los avisos y las capas de consola, confirmación y carga. Estas comprobaciones se realizaron en tamaños de 320 × 568, 390 × 844 y 1440 × 1000 px.

Las APIs de Grid fueron simuladas exclusivamente en las pruebas locales; esas simulaciones no están incluidas en el HTML final. La imagen del logo en las pruebas es una fixture de un píxel: solo acredita el flujo de descarga y decodificación, no la imagen real de Mercado Libre. Las fotos se probaron con un dispositivo de cámara virtual de Chromium. No se verificaron una sesión real de Grid, una handheld física, Safari ni la autenticación de producción.

## Uso

Usa el HTML final en el mismo contexto Grid de la app original, conservando sus accesos y configuración. No necesita Next.js, instalar paquetes ni cargar nuevos recursos externos. La carga del logo y las operaciones de datos siguen dependiendo de la sesión y los servicios de Grid existentes.

No se publicó ni se reemplazó ninguna app remota. El archivo original subido permanece intacto.
